<?php 

include_once ('Database.php');


class Owner extends Database
{
	
	function __construct($id)
	{
		$sql="SELECT * FROM startup_owner WHERE id=$id";
		$statement= Database::$db->prepare($sql);
		$statement->execute();
		$data=$statement->fetch(PDO::FETCH_ASSOC);
		foreach ($data as $key => $value) {
			$this->{key}=$value;
		}

	}






//getting values from Form Data into database 

public static function addOwner($name,$pass,$email,$mobileNum,$National_ID){

$sql= "INSERT INTO startup_owner(name,password,email,phoneNumber,National_ID) VALUES (?,?,?,?,?)";
Database::$db->prepare($sql)->execute([$name,$pass,$email,$mobileNum,$National_ID]);
}



/*public static function addOwnerNatID($National_ID){

//$sql= "INSERT INTO startup_owner (National_ID) VALUES (?) WHERE id= $this->id  " ;
$sql = "UPDATE startup_owner SET National_ID = $National_ID WHERE id = 8 ; ";
Database::$db->prepare($sql)->execute([$National_ID]);
}*/

}




?>