<?php include_once('./common/headwithout.php') ?>

<!DOCTYPE html>
<html>

<style>
html,body,h1,h2,h3,h4,h5 {font-family: "Open Sans", sans-serif}
body{background-color:rgb(206,206,206,1);}   
label{margin: 2%} 

.login-input
{
    
    width: 400px;
    height: 45px; 
    border:1px solid #999;
    padding:5px;
    border-radius: 10px;
           
}    

#submit1
{
    width: 120px;
    height: 45px;
    font-size: 20px;
    font-family: 'Acme';
    background-color: rgba(8,91,135,1);
    color: white;
    border: 0;
    border-radius: 10px;
}
#submit1:active
{
   background-color: rgba(255,255,255,0.2); 
}    
</style>
<body>




   <div class="login" style="margin-left:20px; text-align: center" >
        <form method="post" action="home.php">
           <br><br><br><br><br><br><br><br><br>
            <label> Name :</label>
            <input class="login-input" type="text" placeholder="Name" id="username1" name="username1"><br><br><br>
            <label>Password :</label>
            <input class="login-input" type="password" placeholder="password" id="password1" name="password4"><br><br>
            <input type="submit" name="submit1"value="Login" id="submit1" style="width:25%">
            <br><br>
            <a href="signupcustomer.php">create a new account ?</a>
            <br><br>
        </form>  
    </div>  
    
    
</body>
</html>






<?php
include_once('./models/customers.php');
include_once('./models/owners.php');
include_once ('./controllers/LoginFormControlCustomer.php');


//echo "3abat";

 ?>