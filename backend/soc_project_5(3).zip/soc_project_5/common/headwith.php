<!DOCTYPE html>
<html>
<title>startups on cloud</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-blue-grey.css">
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans'>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    
<style>
html,body,h1,h2,h3,h4,h5 {font-family: "Open Sans", sans-serif}
</style>
<body class="w3-theme-l5">

<!-- Navbar -->
<div class="w3-top">
 <div class="w3-bar w3-theme-d5 w3-left-align w3-large">
  
  <a href="./home.php" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white" title="Home"><i class="fa fa-globe"></i> Home</a>
 
 <a href="contactuswith.php" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white" title="contact us"><i class="fa fa-envelope"></i> Contact us</a>
     
 <a href="aboutwith.php" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white" title="About"><i class="fa fa-user"></i> About</a>

 <a href="editCustomerPage.php" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white" title="Edit"><i class="fa fa-user"></i> Edit</a>
 
   
<img src="img/logo.png" class="w3-circle" style="height:40px;width:40px ; float:right; margin-right:15%;" alt="logo">
 <form action="../index.php">
 

<input type=submit class="btn btn-outline-success" style=" background-color:rgba(8,91,135,1); border :none; color: white;text-align: center;text-decoration: none;float:right; margin-right:5%;" value="Log out " >

</form>
     
</div>
</div> 

    
    
 
    </body>      

</html>
