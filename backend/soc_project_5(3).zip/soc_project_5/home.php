
<?php
session_start();
$_SESSION['id'] = $row['id'];
 include_once('./common/headwith.php');
//$customerid=$_SESSION['userID'];
 ?>

<!DOCTYPE html>
<html>
<title>startups on cloud</title>

<style>
html,body,h1,h2,h3,h4,h5 {font-family: "Open Sans", sans-serif}
</style>
<body class="w3-theme-l5">


        
       
    <!--categorys-->
    
    <div class="container-fluid text-center bg-grey">
        <br><br>
        <img src="img/logo.png" alt="clouds" >
        <br><br>
  <div class="row text-center">
    <div class="col-sm-4">
      <div class="card">
        <img class="card-img-top" src="img/food.jpg" alt="Restaurant" width="400" height="300">
        <div class="card-body">
        <a href="restaurant.php" ><strong >Restaurant</strong></a>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat <b>CLICK ON "Restaurant" to link Category page</b></p>
      </div>
    </div>
    </div>
    <div class="col-sm-4">
      <div class="thumbnail">
        <img src="img/shopping.jpg" alt="shopping" width="400" height="300">
        <a href="shopping.php" ><strong >Shopping</strong></a>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat</p>
      </div>
    </div>
    <div class="col-sm-4">
      <div class="thumbnail">
        <img src="img/img3.jpg" alt="games" width="400" height="300">
        <p><strong>Games and Entertainment</strong></p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat</p>
      </div>
    </div>
       <div class="col-sm-4">
       <div class="card" style="margin-top:  10px">
        <img class="card-img-top" src="img/img4.jpg" alt="Restaurant" width="400" height="300">
        <div class="card-body">
        <a href="Category.php" ><strong >Wedding planner</strong></a>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat </p>
      </div>
    </div>
    </div>
    <div class="col-sm-4">
      <div class="thumbnail">
        <img src="img/co3.jpg" alt="shopping" width="400" height="300">
        <p><strong>Co-Working spaces</strong></p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat</p>
      </div>
    </div>
    
  </div>
</div>

     <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
   <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
       
    
 
    </body>      

</html>

<?php
//session_start();
//$_SESSION['id'] = $row['id']; 
//include_once('./common/headowner.php') ; 
include_once('./models/customers.php');
include_once('./models/owners.php');
include_once('./controllers/LoginFormControlCustomer.php');
//session_start();
//$row=[];
//$_SESSION['id'] = $row['id'];
if ($_SESSION['startups_on_the_cloud']=false) {
  echo "session variables arenot setted,please log in first";
   //echo" $customerid";
  //print_r( $_SESSION['startups_on_the_cloud']); 
   header('location:logincustomer.php');

    }
    else {
    echo "session variables are setted";
    echo $_SESSION['id'];
    }

?>


