<?php

include_once('./models/owners.php');
include_once('./models/customers.php');
include_once('./controllers/common.php');
include_once('./models/Database.php');
Database::connect('startups_on_the_cloud','root','');

//$username = $_POST['username1'];
//$password = $_POST['password4'];

$username = safeGet("username1");
$password = safeGet("password4");

$sql = "SELECT COUNT(*) FROM startup_owner WHERE name = '$username' and password = '$password' ;";
$result = Database::$db->query($sql);

//check number of rows available (is this user is has already signed up?)

if($result)
{

if ($result->fetchColumn() == 1)
	{   

		session_start();
		$_SESSION['startups_on_the_cloud']=true;
		$sql2="SELECT id FROM startup_owner WHERE name = '$username' and password = '$password' ; ";
		$result2 = Database::$db->query($sql2);
        foreach ($result2 as $row) {
        	$id = $row['id'];
            echo  "id: " .  $row['id'] . "\n";
        }
		header('location:owner.php?id='.$id);
		//echo "session start";
	}
}

else 
{
	echo "wrong username or password ,please chack if u have already signed up";

}





?>