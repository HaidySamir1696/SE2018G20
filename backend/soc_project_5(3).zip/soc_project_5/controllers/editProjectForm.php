<?php
session_start();
include_once('./models/owners.php');
include_once('./models/projects.php');
include_once('./controllers/common.php');
Database::connect('startups_on_the_cloud','root','');

if (isset($_POST['projectName'])) {
	Project::edit_name(safePOST("projectName"),$_SESSION['ProjectIdOfOwner']);
	echo "Project name updated!!";
}

if (isset($_POST['cate'])) {
	Project::edit_category(safePOST("cate"),$_SESSION['ProjectIdOfOwner']);
	echo "Project category updated!!";
}

if (isset($_POST['projectPhoto'])) {
	Project::edit_Pimage(safePOST("projectPhoto"),$_SESSION['ProjectIdOfOwner']);
	echo "Project photo updated!!";
}

if (isset($_POST['location'])) {
	Project::edit_location(safePOST("location"),$_SESSION['ProjectIdOfOwner']);
	echo "Project location updated!!";
}

if (isset($_POST['description'])) {
	Project::edit_description(safePOST("description"),$_SESSION['ProjectIdOfOwner']);
	echo "Project descroption updated!!";
}

else {
	echo "False!!";
}

?>
