<?php
session_start();
include_once('./models/headowner.php');
if(isset($_REQUEST['btn']))
{
    echo 'Button is clicked';
session_unset();
session_destroy();
header('location:../loginowner.php');
exit();

}



?>