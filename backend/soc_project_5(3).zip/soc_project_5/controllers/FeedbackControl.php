<?php

include_once('./models/owners.php');
include_once('./models/customers.php');
include_once('./controllers/common.php');
include_once('./models/Database.php');
Database::connect('startups_on_the_cloud','root','');















 ?>
