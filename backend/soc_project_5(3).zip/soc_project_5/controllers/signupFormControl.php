<?php 
//include_once('./models/owners.php');
include_once('./models/customers.php');
include_once('./controllers/common.php');
Database::connect('startups_on_the_cloud','root','');



if(isset($_POST['username2']) && isset($_POST['password3']) && isset($_POST['phonenumber'])
	&& isset($_POST['email']) )
{	
	echo 'done customer';
    Customer::addCustomer(safeGet("username2"),safeGet("password3"),safeGet("email"),safeGet("phonenumber"));
 
}	

if( isset($_POST['username2']) && isset($_POST['password3']) && isset($_POST['phonenumber'])
	&& isset($_POST['email']) && isset($_POST['nationalID']))
{ 
	echo 'done owner step1';
	Owner::addOwner(safeGet("username2"),safeGet("password3"),safeGet("email"),safeGet("phonenumber"),safeGet("nationalID"));
	
}
	

else {
echo "fail";
}




 ?>




