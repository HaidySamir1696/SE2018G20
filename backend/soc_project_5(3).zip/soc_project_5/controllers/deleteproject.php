<?php
	header('Content-Type: application/json; charset=utf-8');
	include_once("../models/projects.php");
	Database::connect('startups_on_the_cloud','root','');
	
	$project = new Project($_GET['ProjectID']);
	$project->deleteProject();
	echo json_encode(['status'=>1]);
?>