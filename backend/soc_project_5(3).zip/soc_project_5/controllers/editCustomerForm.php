<?php
session_start();
include_once('./controllers/common.php');
include_once('./models/customers.php');
Database::connect('startups_on_the_cloud','root','');

if (isset($_POST['username2'])) {
	Customer::edit_name(safeGet("username2"),$_SESSION['userID']);
	//echo "Name updated!";
	
}

if (isset($_POST['password3'])) {
	Customer::edit_Password(safeGet("password3"),$_SESSION['userID']);
	//echo "Password updated!";
}

if (isset($_POST['email'])) {
	Customer::edit_mail(safeGet("email"),$_SESSION['userID']);
	//echo "Email updated!";
}

if (isset($_POST['phonenumber'])) {
	Customer::edit_phone(safeGet("phonenumber"),$_SESSION['userID']);
	//echo "Phone number updated";
}
else {
	//echo "False!!";
}

?>