<?php include_once('./common/headwithout.php') ?>


<html>
<head>
<style>
html,body,h1,h2,h3,h4,h5 {font-family: "Open Sans", sans-serif}
    
label{font-size: 35px;font-family: 'Acme';}

.contact-input
{
    
    width: 400px;
    height: 45px; 
    border:1px solid #999;
    padding:5px;
    border-radius: 10px;
           
}    

#text_area
{
    
    width: 600px;
    height: 100px;
    border-radius: 10px;
     
}
#submit3
{
    width: 120px;
    height: 45px;
    font-size: 20px;
    font-family: 'Acme';
    background-color: rgba(8,91,135,1);
    color: white;
    border: 0;
    border-radius: 10px;
}
#submit3:active
{
   background-color: rgba(255,255,255,0.2); 
}
    
</style>
    
    </head>
<body class="w3-theme-l5">




   <div class="contact" style="margin-left:20px; text-align: center" >
        <form method="post" action="contactus2.php">
           <br><br><br><br><br>
            <h1 style=" color : blue ;font-size :40px"> Tell us about your opinion</h1>
            <br>
            <label> Name :</label><br>
            <input class="contact-input" type="text" placeholder="Name" id="username3" name="username3"><br><br><br>
            <label> E-mail :</label><br>
            <input class="contact-input" type="text" placeholder="Email" id="email3" name="email3"><br><br><br>
            <label> Phone Number :</label><br>
            <input class="contact-input" type="text" placeholder="Phone" id="phonenumber3" name="phonenumber3"><br><br>
            <div style="font-size :25px;">
            <label>How do you see the website ?</label><br><br>
            <input type="radio" name="rate">
            <lable>Excellent</lable>  
            <input type="radio" name="rate">
            <lable>Very good</lable>  
            <input type="radio" name="rate">
            <lable>Good</lable>  
            <input type="radio" name="rate">
            <lable>Poor</lable>
            </div>    
            <br><br><br>
            <label > What's your opinion ?</label><br>
            <textarea id="text_area" placeholder=" your message" name="text_area" ></textarea>
            <br><br><br><br><br>
            <input type="submit" name="submit3" id="submit3">
            <br><br><br><br>
        </form>  
    </div>
    
    
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
   <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    
    </body>      

</html>