<?php include_once('./common/headwithout.php');
include_once('./models/owners.php');
include_once('./models/projects.php');
include_once ('./controllers/deleteproject.php');
?>


<html>
<title>startups on cloud</title>
<head>
<style>
html,body,h1,h2,h3,h4,h5 {font-family: "Open Sans", sans-serif}
body{background-color:rgb(206,206,206,1);}   
    
 label
    {
        font-family: cursive;
        font-size: 25px;
    }
    
    
 .main
    {
        position:absolute;
         padding: 2% ; 
         margin: 2%;
        text-align: center;
    }
    
    
body{
    background-color:black;
    }     


.signup-info
{
    
    width: 300px;
    height: 45px; 
    border:1px solid #999;
    padding:5px;
    border-radius: 10px;
           
}    

#submit
{
    width: 120px;
    height: 45px;
    font-size: 20px;
    font-family: 'Acme';
    background-color: rgba(8,91,135,1);
    color: white;
    border: 0;
    border-radius: 10px;
}
textarea{
    border:1px solid #999;
    padding:5px;
    border-radius: 10px;        
    }
#submit:hover
{
   background-color:lightblue; 
}      
    
    </style>
    
</head>
    
<body class="w3-theme-l5">

<br><br>
    
<div class="main">
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post" id="data">
        
    <label> Are you sure you want to delete this project? </label>
    <button type="button" class="w3-button w3-theme-d1 w3-margin-bottom" onclick="location.href='deleteproject.php';"> Yes</button> 
    <button type="button" class="w3-button w3-theme-d2 w3-margin-bottom" class="button delete_student" id="<?=$project->ProjectID?>" onclick="location.href='owner.php'">No</button> 
    
</div>
    
</body>

</html>
