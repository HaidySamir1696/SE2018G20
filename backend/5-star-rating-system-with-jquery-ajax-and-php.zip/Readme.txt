Author: Yogesh singh
Author URL: http://makitweb.com/
Author Email: yogesh@makitweb.com
Tutorial Link: http://makitweb.com/5-star-rating-system-with-jquery-ajax-and-php/

### Instructions ###

1. Load attached posts and post_rating sql files in your database.
2. Update config.php file.