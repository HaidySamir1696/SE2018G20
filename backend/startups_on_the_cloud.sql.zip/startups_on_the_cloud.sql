-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 14, 2019 at 11:51 AM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `startups_on_the_cloud`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phoneNumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `name`, `password`, `email`, `phoneNumber`) VALUES
(1, 'mariam', 'miro', 'marioma@gmail.com', 1001023578),
(2, 'fatmaa', 'tomy', 'tomy@gmail.com', 1234568923),
(3, 'monssssss', 'ssssss', 'mon@gmail.com', 202022);

-- --------------------------------------------------------

--
-- Table structure for table `feedbacks`
--

CREATE TABLE `feedbacks` (
  `id` int(11) NOT NULL,
  `Project ID` int(11) NOT NULL,
  `customer id` int(11) NOT NULL,
  `feedback` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE `project` (
  `ProjectID` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `rating` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `project`
--

INSERT INTO `project` (`ProjectID`, `name`, `category`, `location`, `description`, `rating`) VALUES
(1, 'beet ard', 'Restaurant', 'https://www.youtube.com/', 'gamel', 5),
(3, 'beet woorod keteer', 'Restaurant', 'https://www.youtube.com/', 'cvhjklkmn', 5),
(4, 'beet woorod keteer', 'Restaurant', 'https://www.youtube.com/', 'cvhjklkmn', 5),
(5, 'gherhreh', 'Restaurant', 'https://www.youtube.com/', 'klplokjn', 5),
(6, 'meshwar', 'Restaurant', 'https://www.youtube.com/', 'gamel', 5),
(7, 'willys', 'Restaurant', 'https://www.youtube.com/', 'ra23', 5),
(8, '3otor', 'Shopping', 'https://www.youtube.com/', 'a7la 3otor', 5),
(9, 'lebsmostwrd', 'Open Days', 'https://www.youtube.com/', 'lebs r5es', 5),
(10, 'coiffeur', 'Restaurant', 'https://www.youtube.com/', 'gameeeeeeeeeeeeeeeel', 5),
(11, 'adwat', 'Games and Entertainment', 'https://www.youtube.com/', 't7fa', 5),
(12, 'willys 2', 'Restaurant', 'https://www.youtube.com/', 'woowww', 5);

-- --------------------------------------------------------

--
-- Table structure for table `promocodes`
--

CREATE TABLE `promocodes` (
  `id` int(11) NOT NULL,
  `Project ID` int(11) NOT NULL,
  `customer id` int(11) NOT NULL,
  `owner id` int(11) NOT NULL,
  `promocode` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `secondary_photos`
--

CREATE TABLE `secondary_photos` (
  `id` int(11) NOT NULL,
  `Project ID` int(11) NOT NULL,
  `secondary photo link` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `startup_owner`
--

CREATE TABLE `startup_owner` (
  `id` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phoneNumber` int(11) NOT NULL,
  `National_ID` int(20) NOT NULL,
  `Project_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `startup_owner`
--

INSERT INTO `startup_owner` (`id`, `name`, `password`, `email`, `phoneNumber`, `National_ID`, `Project_ID`) VALUES
(9, '0', '1234567', 'dodo@gmail.com', 109644207, 2147483647, 1),
(10, '0', '123', 'haidy11@gmail.com', 109644207, 2147483647, 0),
(11, '0', '1234567', 'dodo@gmail.com', 109644207, 2147483647, 0),
(12, '0', 'loly', 'fatma65@gmail.com', 1234567885, 2147483647, 0),
(13, '0', 'loly', 'fatma65@gmail.com', 1234567885, 2147483647, 0),
(14, '0', 'noodyna', 'nadoud@gmail.com', 109644207, 2147483647, 0),
(15, '0', 'noodyna', 'nadoud@gmail.com', 109644207, 2147483647, 0),
(16, '0', 'mony', 'menna.hussien.ali@gmail.com', 109644207, 2147483647, 0),
(17, '0', '1234', 'menna.hussien.ali@gmail.com', 1061488896, 2147483647, 0),
(18, '0', '7542', 'haidy11@gmail.com', 202022, 2147483647, 0),
(19, '0', '', 'tomy_95@gmail.com', 1234567885, 2147483647, 5),
(20, '0', '', 'tomy_95@gmail.com', 1234567885, 2147483647, 5),
(21, '0', 'monmon', 'monmon_77@gmail.com', 109644207, 2147483647, 0),
(22, '0', 'monmon', 'monmon_77@gmail.com', 109644207, 2147483647, 2),
(23, '0', 'monmon', 'monmon_77@gmail.com', 109644207, 2147483647, 2),
(24, '0', 'monmon', 'monmon_77@gmail.com', 109644207, 2147483647, 2),
(25, '0', 'lolyyy', 'esraa@gmail.com', 188234556, 2147483647, 0),
(26, '0', 'lolyyy', 'esraa@gmail.com', 188234556, 2147483647, 0),
(27, '0', 'lolyyy', 'esraa@gmail.com', 188234556, 2147483647, 0),
(28, '0', 'gewgw', 'esraa@gmail.com', 5236363, 2147483647, 0),
(29, '0', 'gewgw', 'esraa@gmail.com', 5236363, 2147483647, 0),
(30, '0', '', '', 0, 0, 0),
(31, '0', '', '', 0, 0, 0),
(32, '0', 'mnbvghj', 'menna.hussien.ali@gmail.com', 1061488896, 2147483647, 0),
(33, '0', 'mnbvghj', 'menna.hussien.ali@gmail.com', 1061488896, 2147483647, 0),
(34, '0', '', '', 0, 0, 0),
(35, '0', '', '', 0, 0, 0),
(36, '0', 'qfghjlksm', 'haidy11@gmail.com', 109644207, 101010101, 0),
(37, '0', 'soso', 'soso_87@gmail.com', 1061488896, 2147483647, 0),
(38, '0', 'soso', 'soso_87@gmail.com', 1061488896, 2147483647, 0),
(39, '0', 'miro', 'marmar@gmail.com', 109644207, 2147483647, 0),
(40, '0', 'miro', 'marmar@gmail.com', 109644207, 2147483647, 0),
(41, '0', 'jhgkyfkg', 'menna.hussien.ali@gmail.com', 109644207, 2147483647, 0),
(42, '0', 'jhgkyfkg', 'menna.hussien.ali@gmail.com', 109644207, 2147483647, 0),
(43, '0', ',,,,,,,,,,,,,', 'menna.hussien.ali@gmail.com', 109644207, 2147483647, 0),
(44, '0', '12345678', 'lul@gmail.com', 202022, 2147483647, 0),
(45, '0', 'lolo', 'mona11@gmail.com', 109644207, 2147483647, 5),
(46, '0', 'allaah w akbr', 'abdo@gmail.com', 1061488896, 2147483647, 6),
(47, 'abdelhamid', 'habaloloy', 'abdelhamid@gmail.com', 109644207, 2147483647, 7),
(48, 'pola', 'polal1234', 'pola@hotmail.com', 1061488896, 2147483647, 8),
(49, 'hussien', 'sonson', 'hussien123@gmail.com', 109644207, 2147483647, 9),
(50, 'nihal', 'nono', 'nono@gmail.com', 109644207, 2147483647, 10),
(51, 'noor', 'nory', 'nornor@gmail.com', 109644207, 2147483647, 11),
(52, 'esraa yaser', 'soso', 'soso@gmail.com', 1061488896, 2147483647, 12);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `feedbacks`
--
ALTER TABLE `feedbacks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `REFRENCES` (`Project ID`),
  ADD KEY `add` (`customer id`);

--
-- Indexes for table `project`
--
ALTER TABLE `project`
  ADD PRIMARY KEY (`ProjectID`);

--
-- Indexes for table `promocodes`
--
ALTER TABLE `promocodes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `REFRENCES` (`Project ID`),
  ADD KEY `VIEW` (`customer id`),
  ADD KEY `generate` (`owner id`);

--
-- Indexes for table `secondary_photos`
--
ALTER TABLE `secondary_photos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `startup_owner`
--
ALTER TABLE `startup_owner`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `feedbacks`
--
ALTER TABLE `feedbacks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `project`
--
ALTER TABLE `project`
  MODIFY `ProjectID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `promocodes`
--
ALTER TABLE `promocodes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `secondary_photos`
--
ALTER TABLE `secondary_photos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `startup_owner`
--
ALTER TABLE `startup_owner`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `feedbacks`
--
ALTER TABLE `feedbacks`
  ADD CONSTRAINT `add` FOREIGN KEY (`customer id`) REFERENCES `customer` (`id`);

--
-- Constraints for table `promocodes`
--
ALTER TABLE `promocodes`
  ADD CONSTRAINT `generate` FOREIGN KEY (`owner id`) REFERENCES `startup_owner` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
