<?php session_start();
include_once('./models/projects.php');
include_once('./controllers/common.php');
include_once('./models/owners.php');
include_once('./common/headowner.php') ; 
include_once('./models/customers.php');
//include_once('./models/owners.php');
include_once('./controllers/LoginFormControlOwner.php');
include_once('./models/projects.php');
//only logged in user can access this page
//session_start();
$detail = Owner::OwnerProject($_SESSION['id'])[0];

//print_r($detail); 
  # code...
  $projectName = $detail['name'];
  //echo $projectName;
  $projectDesc = $detail['description'];
  $projectLocation = $detail['location'];
  $projectCategory = $detail['category'];
  $projectImage = $detail['primary_image'];
  $OwnerEmail = $detail['email'];
  $OwnerPhone = $detail['phoneNumber'];
  
if (!$_SESSION['startups_on_the_cloud']) {
 
   echo "session variables arenot setted,please log in first";
   print_r( $_SESSION['startups_on_the_cloud']); 
   header('location:loginowner.php');

    }
    else{  echo "session variables are setted";
    
           echo $_SESSION['id'];
    }

//$_SESSION['id'] = $row['userid'];
 //echo $_SESSION['projectName'];
 ?>
<!DOCTYPE html>
<html>
<title>My profile</title>

<style>
html,body,h1,h2,h3,h4,h5 {font-family: "Open Sans", sans-serif}
</style>
<body class="w3-theme-l5">




<!-- Page Container -->
<div class="w3-container w3-content" style="max-width:1400px;margin-top:80px">    
  <!-- The Grid -->
  <div class="w3-row">
    <!-- Left Column -->
    <div class="w3-col m3">
      <!-- Profile -->
      <div class="w3-card w3-round w3-white">
        <div class="w3-container">
        <h4 class="w3-center">My Profile</h4>
         <p name="profileName"><i class="fa fa-pencil fa-fw w3-margin-right w3-text-theme"></i> <?= $_SESSION['username']?></p>
         <p name="profileE-mail"><i class="fa fa-home fa-fw w3-margin-right w3-text-theme"></i> <?= $OwnerEmail ?></p>
         <p name="profileMobile"><i class="fa fa-birthday-cake fa-fw w3-margin-right w3-text-theme"></i> <?= $OwnerPhone ?></p>
        </div>
      </div>
      <br>
      
      <!-- Accordion -->
      <div class="w3-card w3-round">
        <div class="w3-white">
       
          <button  class="w3-button w3-block w3-theme-l1 w3-left-align"><i class="fa fa-calendar-check-o fa-fw w3-margin-right"></i> Rates</button>
          
          <button onclick="myFunction('Demo3')" class="w3-button w3-block w3-theme-l1 w3-left-align"><i class="fa fa-users fa-fw w3-margin-right"></i> No. of Promo Codes</button>
          <div id="Demo3" class="w3-hide w3-container">
            <div class="w3-row-padding">
              <br>
                   <div >
                    <form>
                <input name="PrmoNumber" type="text" class="w3-button w3-theme-d1 w3-margin-bottom">
                   </div>
                   <div >
                <input type="submit" class="w3-button w3-theme-d1 w3-margin-bottom" value="ADD"> 
              </form>
                   </div>
                   

            </div>
          </div>
        </div>      
      </div>
      <br>
      
    <!-- End Left Column -->
    </div>
    
    <!-- Middle Column -->
    <div class="w3-col m7">
    
      
      <div class="w3-container w3-card w3-white w3-round w3-margin"><br>
        <img src="primary_image/<?php echo $projectImage ; ?>" alt="photo" class="w3-left w3-circle w3-margin-right" style="width:60px">
       
         <span class="w3-right w3-opacity"><?= $projectLocation?></span><br/>
          <span class="w3-right w3-opacity"><?= $projectCategory?></span><br/>
      
      
        <h4><?= $projectName?></h4>
        <hr class="w3-clear">
        <span dir="ltr" class="w3-opacity"><?= $projectDesc?></span>
        <br/>
        
       <br>
       
        <button type="button" class="w3-button w3-theme-d1 w3-margin-bottom">  Edit</button> 
        <button type="button" class="w3-button w3-theme-d2 w3-margin-bottom" class="button delete_student" id="<?=$project->ProjectID?>">  Delete</button> 
      </div>
      
    

     
      
    <!-- End Middle Column -->
    </div>
    
   
    
  <!-- End Grid -->
  </div>
  
<!-- End Page Container -->
</div>

 
<script>
// Accordion
function myFunction(id) {
    var x = document.getElementById(id);
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
        x.previousElementSibling.className += " w3-theme-d1";
    } else { 
        x.className = x.className.replace("w3-show", "");
        x.previousElementSibling.className = 
        x.previousElementSibling.className.replace(" w3-theme-d1", "");
    }
}

// Used to toggle the menu on smaller screens when clicking on the menu button
function openNav() {
    var x = document.getElementById("navDemo");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}

////////////
  $(document).ready(function() {
    /*$('.edit_student').click(function(event) {
      window.location.href = "editstudent.php?id="+$(this).attr('id');
    });*/
  
    $('.delete_project').click(function(){
      var anchor = $(this);
      $.ajax({
        url: './controllers/deleteproject.php',
        type: 'GET',
        dataType: 'json',
        data: {id: anchor.attr('id')},
      })
      .done(function(reponse) {
        if(reponse.status==1) {
          anchor.closest('tr').fadeOut('slow', function() {
            $(this).remove();
          });
        }
      })
      .fail(function() {
        alert("Connection error.");
      })
    });
  });


</script>

</body>
</html> 






<?php
//session_start(); 



?>

