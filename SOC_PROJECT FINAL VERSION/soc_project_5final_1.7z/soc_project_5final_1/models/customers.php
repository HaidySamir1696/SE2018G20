<?php 

include_once ('Database.php');


class Customer extends Database
{
	
	function __construct($id)
	{
		$sql="SELECT * FROM customer WHERE id=$id";
		$statement= Database::$db->prepare($sql);
		$statement->execute();
		$data=$statement->fetch(PDO::FETCH_ASSOC);
		foreach ($data as $key => $value) {
			$this->{key}=$value;
		}

	}






//getting values from Form Data into database 

public static function addCustomer($name,$pass,$email,$mobileNum){

$sql= "INSERT INTO customer (name,password,email,phoneNumber) VALUES (?,?,?,?)";
 Database::$db->prepare($sql)->execute([$name,$pass,$email,$mobileNum]);
}





}




?>