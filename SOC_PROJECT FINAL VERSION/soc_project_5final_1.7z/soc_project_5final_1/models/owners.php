<?php 

include_once ('Database.php');


class Owner extends Database
{
	
	function __construct($id)
	{
		$sql="SELECT * FROM startup_owner WHERE id=$id";
		$statement= Database::$db->prepare($sql);
		$statement->execute();
		$data=$statement->fetch(PDO::FETCH_ASSOC);
		foreach ($data as $key => $value) {
			$this->{$key}=$value;
		}

	}






//getting values from Form Data into database 

public static function addOwner($name,$pass,$email,$mobileNum,$National_ID,$ans){

$sql= "INSERT INTO startup_owner(name,password,email,phoneNumber,National_ID,Project_ID
) VALUES (?,?,?,?,?,?)";
Database::$db->prepare($sql)->execute([$name,$pass,$email,$mobileNum,$National_ID,$ans]);
}



/*public static function addOwnerNatID($National_ID){

//$sql= "INSERT INTO startup_owner (National_ID) VALUES (?) WHERE id= $this->id  " ;
$sql = "UPDATE startup_owner SET National_ID = $National_ID WHERE id = 8 ; ";
Database::$db->prepare($sql)->execute([$National_ID]);
}*/



///owner project
public static function OwnerProject($OwnerId){
	//echo "here";

$sql="SELECT id,email,phoneNumber,Project_ID, project.name ,project.location , project.category , project.description,secondary_photos.primary_image FROM `startup_owner` JOIN `project` ON project.ProjectID = startup_owner.Project_ID 
JOIN `secondary_photos` ON secondary_photos.ProjectID = startup_owner.Project_ID   WHERE id = '$OwnerId';";

$statement= Database::$db->prepare($sql);
//echo "here1";
$statement->execute();
//echo "here2";
$projectdet = [];
			while($row = $statement->fetch(PDO::FETCH_ASSOC)) {
				//echo $row['id'];
				$projectdet[] = $row ; 
				              
				//deh enty 3rafaha b2a bebsata y3ny fetch hatrg3 array mndata ely mwgoda fe eltable 7aletna hna eltable hoa students .....lama hatktby row['id'] id hna betmsl esm elcoloum ely enty 3aiza mno 7aga
			}
			//print_r($projectdet);  
			return $projectdet;
			
			
			


}

}
?>