<?php 
include_once('./models/customers.php');
include_once('./models/owners.php');
include_once ('./controllers/signupFormControl.php');



// define variables and set to empty values
$nameErr = $emailErr = $genderErr = $websiteErr = "";
$name = $email = $gender = $comment = $website = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["username2"])) {
    $nameErr = "Name is required";
  } else {
    $name = test_input($_POST["username2"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
      $nameErr = "Only letters and white space allowed"; 
    }
  }
  
  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
    // check if e-mail address is well-formed
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

      $emailErr = "Invalid email format"; 
    }
  }
    
  

}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

?>









<?php include_once('./common/headwithout.php') ?>

<html>

<style>
html,body,h1,h2,h3,h4,h5 {font-family: "Open Sans", sans-serif}
body{background-color: darkgrey}     
label{margin: 2%} 
body{background-color:rgb(206,206,206,1);}   
.signup-input
{
    
    width: 400px;
    height: 45px; 
    border:1px solid #999;
    padding:5px;
    border-radius: 10px;
           
}    

#submit2
{
    width: 120px;
    height: 45px;
    font-size: 20px;
    font-family: 'Acme';
    background-color: rgba(8,91,135,1);
    color: white;
    border: 0;
    border-radius: 10px;
}
#submit2:active
{
   background-color: rgba(255,255,255,0.2); 
}      
</style>
<body>
 


   <div class="signup" style="margin-left:20px; text-align: center" >
          
        <form  action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
            <br><br><br><br><br><br><br><br><br>
            <label> Name</label>
            <input class="signup-input" type="text" placeholder="Name" id="username2" name="username2" value="<?php echo $name;?>" required>
            <span class="error"> <?php echo "$nameErr"; ?></span>
            <br>
            <label>Password</label>
            <input class="signup-input" type="password" placeholder="password" id="password2" name="password3" 
            max="15" required><br>
            <label>E-mail</label>
            <input class="signup-input" type="email" name="email" placeholder="email" id="email" value="<?php
             echo $email;?>" required><br>
            <span class="error"> <?php echo"$emailErr";?> </span>
            <label>MobileNo.</label>
            <input class="signup-input" type="tel"  name="phonenumber" placeholder="phonenumber" id="phonenumber" minlength="11" maxlength="11" required><br><br>
           <br><br><br>
            <input type="submit" name="submit2" value="sign up" id="submit2" style="width:25%">
            <br><br>
         </form>  
    </div>  
    
    
</body>
</html>


