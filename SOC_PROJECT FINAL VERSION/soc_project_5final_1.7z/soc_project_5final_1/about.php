<?php include_once('./common/headwithout.php') ?>
    
    
 <div style="text-align: center; font-family: sans-serif;">
        <br><br><br><br>
        <img alt="logo" src='img/logo.png'>
        <br><br>
        <p style=" font-size: 25px; text-align:  center;font-family: sans-serif;">Either you are a customer or the owner of the startup, our website will help you a
            lot. Actually, our website provides a wide platform for marketing all kinds of
            startups and helping them to become more popular and stabilizes their work.
            However, it also helps the customers to find a good place which provides services
            with high quality and good cost without any efforts of searching.
            </p>
          <br><br><br><br><br><br><br><br>
          <p>All CopyRights &copy; Reserved For (Team 20)</p>
      </div>
   <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
   <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    
