

<?php include_once('./common/headwithout.php') ?>

<!DOCTYPE html>
<html>

<style>
html, body, h1, h2, h3, h4, h5 {font-family: "Open Sans", sans-serif}

body
    {
        body{background-color:rgb(206,206,206,1);}   
    }
    
.button 
    {
        background-color:rgba(8,91,135,1);
        border :none;
        color: white;
        padding: 30px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 30px;
        margin:7%;
        border-radius: 50%;
        margin-left: 45%;
    }
    
    

</style>
<body class="w3-theme-l5">
    <br><br><br><br><br><br>
<p style="font-family: cursive; font-size: 25px; margin-left:20%"> YOU CAN lOGIN TO OUR WEBSITE STARTUP ON CLOUD </p>
    
    
<div>
   <form action="loginowner.php" method="post"> <button class="button button1">Owner</button></form>
    
    <form action="logincustomer.php" method="post"> <button class="button button2">Customer</button></form>
    
    
    
    </div>

</body>
</html> 
