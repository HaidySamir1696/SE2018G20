<?php
session_start();
include_once('./models/headwith.php');
if(isset($_REQUEST['check']))
{

echo 'Button is clicked';
session_unset();
session_destroy();
header('location:../logincustomer.php');
exit();

}



?>