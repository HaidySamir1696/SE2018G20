<?php
	header('Content-Type: application/json; charset=utf-8');
	include_once("../models/projects.php");
	Database::connect('epiz_22960170_school','epiz_22960170','X9a2KJeeaFHVyhn');
	
	$project = new Project($_GET['ProjectID']);
	$project->deleteProject();
	echo json_encode(['status'=>1]);
?>