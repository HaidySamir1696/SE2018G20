<?php
	include_once('./controllers/common.php');
	include_once('./components/headstudentsview.php');
	include_once('./models/grades.php');
include_once('./models/student.php');
	Database::connect('epiz_22959357_school', 'epiz_22959357', 'rtMwKTZpQVnWmR');
?>
<div style="padding: 10px 0px 10px 0px; vertical-align: text-bottom;">
		<span style="font-size: 125%;">Students</span>
		
	</div>

    <table class="table table-striped">
    	<thead>
	    	<tr>
	      		
	      		<th scope="col">Name</th>
	      		
	    	</tr>
	  	</thead>
	  	<tbody>
		  	<?php	
				$students = Student::all(safeGet('keywords'));
				foreach ($students as $student) {
			?>
    		<tr>

    			<td><?=$student->name?></td>
    			<td>
    				<button class="button  details " id="<?=$student->id?>">details</button>
    				
				</td>
    		</tr>
    		<?php } ?>
    	</tbody>
    </table>

<?php include_once('./components/tail.php') ?>

<script type="text/javascript">
	$(document).ready(function() {
		$('.details').click(function(event) {
			window.location.href = "details.php?id="+$(this).attr('id');
		});
	
		
			
		});

</script>