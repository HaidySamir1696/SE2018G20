<?php
	include_once("./controllers/common.php");
	include_once('./components/headgrades.php');
	include_once('./models/grades.php');
	$id = safeGet('id');
Database::connect('epiz_22959357_school', 'epiz_22959357', 'rtMwKTZpQVnWmR');
	$grades = new Grade ($id);
?>

    <h2 class="mt-4"><?=($id)?"Edit":"Add"?> Grades </h2>

    <form action="controllers/savegrades.php" method="post">
    	<input type="hidden" name="id" value="<?=$grades->get('id')?>">
		<div class="card">
			<div class="card-body">
				<div class="form-group row gutters">
					<label for="inputEmail3" class="col-sm-2 col-form-label">Student ID</label>
					<div class="col-sm-10">
						<input class="form-control" type="number" name="student_id" value="<?=$grades->get('student_id')?>" required><br><br>
                        
					</div>

                    <label for="inputEmail3" class="col-sm-2 col-form-label">Course ID</label>
					<div class="col-sm-10">
                        
                    <input class="form-control" type="number" name="course_id" value="<?=$grades->get('course_id')?>" required><br><br>
                        
					</div>
                    
                    <label for="inputEmail3" class="col-sm-2 col-form-label">Degree</label>
					<div class="col-sm-10">
                        
                        <input class="form-control" type="number" name="degree" value="<?=$grades->get('degree')?>" required><br><br>
                        
					</div>
                    
                    <label for="inputEmail3" class="col-sm-2 col-form-label">Examine AT</label>
					<div class="col-sm-10">
                        
                        <input class="form-control" type="date" name="examine_at" value="<?=$grades->get('examine_at')?>" required>
                        
					</div>
                    
                    
                    
                    
                    
				</div>
		    	<div class="form-group">
		    		<button class="button float-right" type="submit">Add</button>
		    	</div>
		    </div>
		</div>
    </form>

<?php include_once('./components/tail.php') ?>