<?php
	header('Content-Type: application/json; charset=utf-8');
	include_once("../models/courses.php");
Database::connect('epiz_22959357_school', 'epiz_22959357', 'rtMwKTZpQVnWmR');
	$courses = new Course($_GET['id']);
	$courses->delete();
	echo json_encode(['status'=>1]);
?>