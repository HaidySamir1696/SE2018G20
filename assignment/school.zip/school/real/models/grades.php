<?php
	include_once('database.php');

	class Grade extends Database{
     
            
		function __construct($id) {
			$sql = "SELECT * FROM grades WHERE id = $id;";
			$statement = Database::$db->prepare($sql);
			$statement->execute();
			$data = $statement->fetch(PDO::FETCH_ASSOC);
			if(empty($data)){return;}
			foreach ($data as $key => $value) {
				$this->{$key} = $value;
			}
		}
        public static function add($student_id, $course_id, $degree, $examine_at) {
			$sql = "INSERT INTO grades (student_id, course_id, degree, examine_at) VALUES (?,?,?,?)";
			Database::$db->prepare($sql)->execute([$student_id, $course_id, $degree, $examine_at]);
		}
		
		public function delete() {
			$sql = "DELETE FROM grades WHERE id = $this->id;";
			Database::$db->query($sql);
		}

		public function save() {
			$sql = "UPDATE grades SET student_id = ? , course_id =? , degree = ? ,examine_at = ? WHERE id = ?;";
			Database::$db->prepare($sql)->execute([$this->student_id, $this->course_id , $this -> degree, $this->examine_at, $this->id ]);
		}
        public static function all($keyword) {
			$keyword = str_replace(" ", "%", $keyword);
			$sql = "SELECT * FROM grades WHERE degree like ('%$keyword%');";
			$statement = Database::$db->prepare($sql);
			$statement->execute();
			$grades = [];
			while($row = $statement->fetch(PDO::FETCH_ASSOC)) {
				$grades[] = new Grade($row['id']);
			}
			return $grades;
		}
          public static function view($id) {
			
			$sql="SELECT courses.name,grades.degree FROM grades JOIN students ON students.id=grades.student_id INNER JOIN courses ON courses.id=grades.course_id WHERE student_id=$id;";
            $statement = Database::$db->prepare($sql);
			$statement->execute();
              $names=[];
              $degree=[];
              $i=0;
			while($row = $statement->fetch(PDO::FETCH_ASSOC)) {
                
                $names[$i]= $row['name']; 
                $degree[$i]= $row['degree'];
                 /*echo $row['name']."<br><br>" ;*/
                   
                $i=$i+1;
            
            }
           return $names; 
          }
			    public static function viewd($id) {
			
			$sql="SELECT courses.name,grades.degree FROM grades JOIN students ON students.id=grades.student_id INNER JOIN courses ON courses.id=grades.course_id WHERE student_id=$id;";
            $statement = Database::$db->prepare($sql);
			$statement->execute();
              $names=[];
              $i=0;
			while($row = $statement->fetch(PDO::FETCH_ASSOC)) {
                
                $names[$i]= $row; 
                $i=$i+1;
            
            }
           return $names; 
          }		
    
      
    
    
    }
?>