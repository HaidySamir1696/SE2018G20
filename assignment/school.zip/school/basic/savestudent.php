<?php
	include_once("student.php");
	Database::connect('epiz_22959357_school', 'epiz_22959357', 'rtMwKTZpQVnWmR');
	Student::add($_POST['name']);
	header('Location: students.php');
?>