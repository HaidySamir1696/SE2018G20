<?php
	include_once("student.php");
	Database::connect('epiz_22959357_school', 'epiz_22959357', 'rtMwKTZpQVnWmR');
	$keyword = (isset($_GET['keyword']))?$_GET['keyword']:"";
?>
<html>
	<head>
		<script src="/js/jquery.min.js"></script>
	</head>
	<body>
<form action="students.php" method="get">
	<input type="text" name="keyword" value="<?=$keyword?>">&nbsp;
	<input type="submit" value="Search">
</form>
<table border='1'>
<?php
	$students = Student::all($keyword);
	foreach ($students as $student) {
	?>
	<tr>
		<td><?=$student->id?></td> <td><?=$student->name?></td>
		<td>
			<a href="#" class='delete_student' id='<?=$student->id?>'>delete</a>
		</td>
	</tr>
	<?php } ?>
	<script type="text/javascript">
$(document).ready(function() {
	$('.delete_student').click(function(){
		var anchor = $(this);
		$.ajax({
			url: 'ajaxdeletestudent.php',
			type: 'GET',
			dataType: 'json',
			data: {id: anchor.attr('id')},
		})
		.done(function(reponse) {
			if(reponse.status==1) {
				anchor.closest('tr').remove();
			}
		})
		.fail(function() {
			alert("Connection error.");
		})
	})
});
	</script>
</table>
<a href="addstudent.php">Add</a>
	</body>
</html>


