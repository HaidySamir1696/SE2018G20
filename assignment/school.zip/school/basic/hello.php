<?php
	$obj = new stdClass();
	$obj->a = 5;
	$obj->b = 6;
	$obj->c = [1, 2, 3];
	$obj->d = new stdClass();
	$obj->d->m = 7;
	$obj->d->s = ['a'=>1];

	print_r($obj);

?>