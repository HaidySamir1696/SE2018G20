<?php
   include_once('./controllers/common.php');
	include_once('./components/headcourses.php');
	include_once('./models/courses.php');
	Database::connect('epiz_22959357_student', 'epiz_22959357', 'rtMwKTZpQVnWmR');
	
?>
<html>

<div style="padding: 10px 0px 10px 0px; vertical-align: text-bottom;">
		<span style="font-size: 125%;">Courses</span>
		<button class="button float-right edit_courses" id="0">Add Courses</button>
	</div>

    <table class="table table-striped">
    	<thead>
	    	<tr>
	      		<th scope="col">ID</th>
	      		<th scope="col">Course Name</th>
                <th scope="col">Max Degree</th>
                <th scope="col">Study Year</th>
	      		<th scope="col"></th>
	    	</tr>
	  	</thead>
	  	<tbody>
		  	<?php
				$courses =Course::all(safeGet('keywords'));
				foreach ($courses as $course) {
			?>
    		<tr>
    			<td><?=$course->id?></td>
    			<td><?=$course->name?></td>
                <td><?=$course->max_degree?></td>
    			<td><?=$course->study_year?></td>


    			<td>
    				<button class="button edit_courses" id="<?=$course->id?>">Edit</button>&nbsp;
    				<button class="button delete_courses" id="<?=$course->id?>">Delete</button>
				</td>
    		</tr>
    		<?php } ?>
    	</tbody>
    </table>



</html>
<?php include_once('./components/tail.php') ?>


<script type="text/javascript">
	$(document).ready(function() {
		$('.edit_courses').click(function(event) {
			window.location.href = "editcourses.php?id="+$(this).attr('id');
		});

		$('.delete_courses').click(function(){
			var anchor = $(this);
			$.ajax({
				url: './controllers/deletecourses.php',
				type: 'GET',
				dataType: 'json',
				data: {id: anchor.attr('id')},
			})
			.done(function(reponse) {
				if(reponse.status==1) {
					anchor.closest('tr').fadeOut('slow', function() {
						$(this).remove();
					});
				}
			})
			.fail(function() {
				alert("Connection error.");
			})
		});
	});
</script>

