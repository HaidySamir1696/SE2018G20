<?php
   include_once('./controllers/common.php');
	include_once('./components/headgrades.php');
	include_once('./models/grades.php');
   include_once('./models/courses.php');
   include_once('./models/student.php');
	Database::connect('epiz_22959357_student', 'epiz_22959357', 'rtMwKTZpQVnWmR');
	
?>
<html>
    
<br><br><br>

    <table class="table table-striped">
    	<thead>
	    	<tr>
                <th scope="col">course</th>
               <th scope="col">degree</th>
           </tr>
	  	</thead>
	  	<tbody>
		  
            <?php	
				$course_degree =Grade::viewd(safeGet('id'));
                foreach ($course_degree as $course) {
                ?>    
			    <tr>
                <td><?=$course["name"]?></td>  
                <td><?=$course["degree"]?></td>  
                </tr>    
                <?php } ?>
    	</tbody>
    </table>
   

    
</html>
<?php include_once('./components/tail.php') ?>

