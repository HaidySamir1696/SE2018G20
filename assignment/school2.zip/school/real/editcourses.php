<?php
	include_once("./controllers/common.php");
	include_once('./components/headcourses.php');
	include_once('./models/courses.php');
	$id = safeGet('id');
	Database::connect('epiz_22959357_student', 'epiz_22959357', 'rtMwKTZpQVnWmR');
	$courses = new Course ($id);
?>

    <h2 class="mt-4"><?=($id)?"Edit":"Add"?> Course </h2>

    <form action="controllers/savecourses.php" method="post">
    	<input type="hidden" name="id" value="<?=$courses->get('id')?>">
		<div class="card">
			<div class="card-body">
				<div class="form-group row gutters">
					<label for="inputEmail3" class="col-sm-2 col-form-label">Name</label>
					<div class="col-sm-10">
						<input class="form-control" type="text" name="name" value="<?=$courses->get('name')?>" required><br><br>
                        
					</div>

                    <label for="inputEmail3" class="col-sm-2 col-form-label">Max Degree</label>
					<div class="col-sm-10">
                        
                    <input class="form-control" type="number" name="max_degree" value="<?=$courses->get('max_degree')?>" required><br><br>
                        
					</div>
                    
                    <label for="inputEmail3" class="col-sm-2 col-form-label">Study Year</label>
					<div class="col-sm-10">
                        
                        <input class="form-control" type="number" name="study_year" value="<?=$courses->get('study_year')?>" required>
                        
					</div>
                    
                    
                    
                    
                    
				</div>
		    	<div class="form-group">
		    		<button class="button float-right" type="submit">Add</button>
		    	</div>
		    </div>
		</div>
    </form>

<?php include_once('./components/tail.php') ?>