<?php
	include_once("../controllers/common.php");
	include_once("../models/courses.php");
Database::connect('epiz_22959357_student', 'epiz_22959357', 'rtMwKTZpQVnWmR');
	$id = safeGet("id", 0);
	if($id==0) {
		Course::add(safeGet("name"),safeGet("max_degree"),safeGet("study_year"));
    } else {
		$courses = new Course($id);
		$courses->name = safeGet("name");
        $courses->max_degree = safeGet("max_degree");
        $courses->study_year = safeGet("study_year");
		$courses->save();
	}
	header('Location: ../courses.php');
?>