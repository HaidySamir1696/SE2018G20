<?php
	include_once("../controllers/common.php");
	include_once("../models/grades.php");
Database::connect('epiz_22959357_student', 'epiz_22959357', 'rtMwKTZpQVnWmR');
	$id = safeGet("id", 0);
	if($id==0) {
		Grade::add(safeGet("student_id"),safeGet("course_id"),safeGet("degree"),safeGet("examine_at"));
    } else {
        $grades = new Grade($id);
		$grades->student_id = safeGet("student_id");
        $grades->course_id = safeGet("course_id");
        $grades->degree = safeGet("degree");
        $grades->examine_at = safeGet("examine_at");
		$grades->save();
	}
	header('Location: ../grades.php');
?>