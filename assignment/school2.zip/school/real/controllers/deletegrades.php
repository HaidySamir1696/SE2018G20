<?php
	header('Content-Type: application/json; charset=utf-8');
	include_once("../models/grades.php");
	Database::connect('epiz_22959357_student', 'epiz_22959357', 'rtMwKTZpQVnWmR');
	$grades = new Grade($_GET['id']);
	$grades->delete();
	echo json_encode(['status'=>1]);
?>