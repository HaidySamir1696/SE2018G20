<?php
   include_once('./controllers/common.php');
	include_once('./components/headgrades.php');
	include_once('./models/grades.php');
Database::connect('epiz_22959357_student', 'epiz_22959357', 'rtMwKTZpQVnWmR');
	
?>
<html>
    
<div style="padding: 10px 0px 10px 0px; vertical-align: text-bottom;">
		<span style="font-size: 125%;">Grades</span>
		<button class="button float-right edit_grades" id="0">Add Grades</button>
	</div>

    <table class="table table-striped">
    	<thead>
	    	<tr>
	      		<th scope="col">ID</th>
	      		<th scope="col">Student_ID</th>
                <th scope="col">Course_ID</th>
                <th scope="col">Degree</th>
	      		<th scope="col">Examine_At</th>
	    	</tr>
	  	</thead>
	  	<tbody>
		  	<?php	
				$grades =Grade::all(safeGet('keywords'));
				foreach ($grades as $grade) {
			?>
    		<tr>
    			<td><?=$grade->id?></td>
    			<td><?=$grade->student_id?></td>
                <td><?=$grade->course_id?></td>
                <td><?=$grade->degree?></td>
    			<td><?=$grade->examine_at?></td>
                
                
    			<td>
    				<button class="button edit_grades" id="<?=$grade->id?>">Edit</button>&nbsp;
    				<button class="button delete_grades" id="<?=$grade->id?>">Delete</button>
				</td>
    		</tr>
    		<?php } ?>
    	</tbody>
    </table>
   

    
</html>
<?php include_once('./components/tail.php') ?>


<script type="text/javascript">
	$(document).ready(function() {
		$('.edit_grades').click(function(event) {
			window.location.href = "editgrades.php?id="+$(this).attr('id');
		});
	
		$('.delete_grades').click(function(){
			var anchor = $(this);
			$.ajax({
				url: './controllers/deletegrades.php',
				type: 'GET',
				dataType: 'json',
				data: {id: anchor.attr('id')},
			})
			.done(function(reponse) {
				if(reponse.status==1) {
					anchor.closest('tr').fadeOut('slow', function() {
						$(this).remove();
					});
				}
			})
			.fail(function() {
				alert("Connection error.");
			})
		});
	});
</script>

