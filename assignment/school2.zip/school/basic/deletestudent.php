<?php
	include_once("student.php");
	Database::connect('epiz_22959357_student', 'epiz_22959357', 'rtMwKTZpQVnWmR');
	$student = new Student($_GET['id']);
	$student->delete();
	header('Location: students.php');
?>