<html>
	<body>
	<form action="savestudent.php" method="post">
		<div><input type="text" name="name"></div>
		<br/>
		<div><input type="submit" value="Add"></div>
	</form>
	</body>
</html>